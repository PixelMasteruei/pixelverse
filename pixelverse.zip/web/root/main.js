function main(){let e=document.querySelector("#viewport-canvas"),t=new GLWindow(e);if(!t.ok())return;let n=new Place(t);n.initConnection(),GUI(e,t,n)}const GUI=(e,t,n)=>{let o=new Uint8Array([0,0,0]),r=!1,l={x:0,y:0},s,c=document.querySelector("#color-field"),i=document.querySelector("#color-swatch");document.addEventListener("keydown",e=>{switch(e.keyCode){case 189:case 173:e.preventDefault(),_();break;case 187:case 61:e.preventDefault(),y()}}),window.addEventListener("wheel",e=>{let n=t.getZoom();e.deltaY>0?n/=1.05:n*=1.05,t.setZoom(n),t.draw()}),document.querySelector("#zoom-in").addEventListener("click",()=>{y()}),document.querySelector("#zoom-out").addEventListener("click",()=>{_()}),window.addEventListener("resize",e=>{t.updateViewScale(),t.draw()});let a=!1;function d(e,t){a||(a=!0,g(e,t),setTimeout(()=>{a=!1},0))}e.addEventListener("mousedown",e=>{switch(e.button){case 0:r=!0,l={x:e.clientX,y:e.clientY};break;case 1:$({x:e.clientX,y:e.clientY});break;case 2:e.ctrlKey?$({x:e.clientX,y:e.clientY}):d({x:e.clientX,y:e.clientY},o)}}),document.addEventListener("mouseup",e=>{r=!1,document.body.style.cursor="auto"}),document.addEventListener("mousemove",e=>{let n={x:e.clientX,y:e.clientY};r&&(t.move(n.x-l.x,n.y-l.y),t.draw(),document.body.style.cursor="grab"),l=n}),e.addEventListener("touchstart",e=>{s=new Date().getTime(),l={x:e.touches[0].clientX,y:e.touches[0].clientY}});let u=0;document.addEventListener("touchend",e=>{new Date().getTime()-s<100&&new Date().getTime()-u>500&&(g(l,o),u=new Date().getTime())}),document.addEventListener("touchmove",e=>{let n={x:e.touches[0].clientX,y:e.touches[0].clientY};t.move(n.x-l.x,n.y-l.y),t.draw(),l=n}),e.addEventListener("contextmenu",()=>!1),c.addEventListener("change",e=>{let t=c.value.replace(/[^A-Fa-f0-9]/g,"").toUpperCase();for(t=t.substring(0,6);t.length<6;)t+="0";o[0]=parseInt(t.substring(0,2),16),o[1]=parseInt(t.substring(2,4),16),o[2]=parseInt(t.substring(4,6),16),t="#"+t,c.value=t,i.style.backgroundColor=t});let $=e=>{o=t.getColor(t.click(e));let n="#";for(let r=0;r<o.length;r++){let l=o[r].toString(16);1==l.length&&(l="0"+l),n+=l}c.value=n.toUpperCase(),i.style.backgroundColor=n},g=(e,o)=>{var r=i.style.backgroundColor.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);delete r[0];for(var l=1;l<=3;++l)r[l]=parseInt(r[l]).toString(16),1==r[l].length&&(r[l]="0"+r[l]);let s=r.join("");if(o[0]=parseInt(s.substring(0,2),16),o[1]=parseInt(s.substring(2,4),16),o[2]=parseInt(s.substring(4,6),16),e=t.click(e)){let c=t.getColor(e);for(let a=0;a<c.length;a++)if(c[a]!=o[a]){n.setPixel(e.x,e.y,o);break}}},y=()=>{let e=t.getZoom();t.setZoom(1.2*e),t.draw()},_=()=>{let e=t.getZoom();t.setZoom(e/1.2),t.draw()}};
// OpenLayers harita oluşturma
var canvas = document.getElementById("mapCanvas");
var context = canvas.getContext("2d");

// Canvas boyutlarını belirle
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Tam dünya haritası çizimi
function drawWorldMap() {
    context.fillStyle = "#87CEEB"; // Açık mavi renk
    context.fillRect(0, 0, canvas.width, canvas.height);
}

drawWorldMap();

