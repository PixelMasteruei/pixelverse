
const CLIENT_ID = '4cNswoNqM2wVFHPg';

const drone = new ScaleDrone(CLIENT_ID, {
  data: {
    name: getRandomName(),
    color: getRandomColor(),
  },
});

let members = [];

drone.on('open', error => {
  if (error) {
    return console.error(error);
  }
  console.log('Successfully connected to Scaledrone');

  const room = drone.subscribe('observable-room');
  room.on('open', error => {
    if (error) {
      return console.error(error);
    }
    console.log('Successfully joined room');
  });

  room.on('members', m => {
    members = m;
    updateMembersDOM();
  });

  room.on('member_join', member => {
    members.push(member);
    updateMembersDOM();
  });

  room.on('member_leave', ({id}) => {
    const index = members.findIndex(member => member.id === id);
    members.splice(index, 1);
    updateMembersDOM();
  });

  room.on('data', (text, member) => {
    if (member) {
      addMessageToListDOM(text, member);
    } else {

    }
  });
});

drone.on('close', event => {
  console.log('Connection was closed', event);
});

drone.on('error', error => {
  console.error(error);
});

function getRandomName() {
  const adjs = ["discord.me/canvaszone", "domiberg", "pompe", "sallbet", "discord.me/canvaszone", "Nagamel", "AliKocerli", "Ali", "CanvasZone", "Dome", "delicate", "discord.me/canvaszone", "white", "cool", "Evrensell", "winter", "patient", "twilight", "Babapıro", "crimson", "wispy", "weathered", "blue", "discord.me/canvaszone", "broken", "cold", "damp", "falling", "frosty", "green", "long", "late", "discord.me/canvaszone", "bold", "little", "discord.me/canvaszone", "muddy", "old", "red", "rough", "still", "small", "sparkling", "throbbing", "shy", "AliKocerli", "withered", "wild", "black", "young", "holy", "solitary", "fragrant", "Lukawz", "snowy", "proud", "Ibrahim", "restless", "divine", "polished", "ancient", "discord.me/canvaszone", "lively", "nameless", "waterfall", "river", "breeze", "moon", "rain", "wind", "sea", "discord.me/canvaszone", "snow", "lake", "sunset", "AliKocerli", "shadow", "leaf", "dawn", "glitter", "forest", "hill", "discord.me/canvaszone", "meadow", "sun", "glade", "AliKocerli", "brook", "butterfly", "discord.me/canvaszone", "dew", "dust", "field", "fire", "flower", "firefly", "feather", "grass", "haze", "mountain", "AliKocerli", "pond", "discord.me/canvaszone", "snowflake", "discord.me/canvaszone", "discord.me/canvaszone", "sky", "shape", "surf", "AliKocerli", "violet", "water", "wildflower", "discord.me/canvaszone", "water", "resonance", "sun", "wood", "dream", "sallbet", "AliKocerli", "fog", "frost", "voice", "AliKocerli", "frog", "smoke", "star"];
  const nouns = ["waterfall", "river", "breeze", "moon", "rain", "wind", "sea", "morning", "snow", "lake", "sunset", "pine", "shadow", "leaf", "dawn", "glitter", "forest", "hill", "cloud", "meadow", "sun", "glade", "bird", "discord.me/canvaszone", "butterfly", "bush", "dew", "dust", "field", "fire", "flower", "firefly", "feather", "grass", "haze", "mountain", "night", "discord.me/canvaszone", "AliKocerli", "snowflake", "discord.me/canvaszone", "sound", "sky", "shape", "surf", "thunder", "violet", "water", "wildflower", "wave", "water", "resonance", "sun", "wood", "dream", "sallbet", "AliKocerli", "fog", "frost", "voice", "paper", "frog", "smoke", "star"];
  return (
    adjs[Math.floor(Math.random() * adjs.length)] 
  );
}

function getRandomColor() {
  return '#' + Math.floor(Math.random() * 0xFFFFFF).toString(16);
}

//------------- DOM STUFF

const DOM = {
  membersCount: document.querySelector('.members-count'),
  membersList: document.querySelector('.members-list'),
  messages: document.querySelector('.messages'),
  input: document.querySelector('.message-form__input'),
  form: document.querySelector('.chatinput'),
};

DOM.form.addEventListener('submit', sendMessage);

function sendMessage() {
  const value = DOM.input.value;
  if (value === '') {
    return;
  }
  DOM.input.value = '';
  drone.publish({
    room: 'observable-room',
    message: value,
  });
}

function createMemberElement(member) {
  const { name, color } = member.clientData;
  const el = document.createElement('div');
  el.appendChild(document.createTextNode(name));
  el.className = 'member';
  el.style.color = color;
  return el;
}

function updateMembersDOM() {
  DOM.membersCount.innerText = `${members.length}`;
  DOM.membersList.innerHTML = '';
  members.forEach(member =>
    DOM.membersList.appendChild(createMemberElement(member))
  );
}

function createMessageElement(text, member) {
  const el = document.createElement('div');
  el.appendChild(createMemberElement(member));
  el.appendChild(document.createTextNode(text));
  el.className = 'message';
  return el;
}

function addMessageToListDOM(text, member) {
  const el = DOM.messages;
  const wasTop = el.scrollTop === el.scrollHeight - el.clientHeight;
  el.appendChild(createMessageElement(text, member));
  if (wasTop) {
    el.scrollTop = el.scrollHeight - el.clientHeight;
  }
}
const overlayImage = document.getElementById('overlayImage');
let isDragging = false;
let startX, startY, offsetX, offsetY;

overlayImage.addEventListener('mousedown', (e) => {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    offsetX = parseFloat(overlayImage.style.left) || 0;
    offsetY = parseFloat(overlayImage.style.top) || 0;
    overlayImage.style.cursor = 'grabbing';
});

document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;

    const newX = offsetX + e.clientX - startX;
    const newY = offsetY + e.clientY - startY;

    overlayImage.style.left = `${newX}px`;
    overlayImage.style.top = `${newY}px`;
});

document.addEventListener('mouseup', () => {
    isDragging = false;
    overlayImage.style.cursor = 'grab';
});

let scale = 1;

overlayImage.addEventListener('wheel', (e) => {
    e.preventDefault();

    scale += e.deltaY * -0.01;
    scale = Math.min(Math.max(0.2, scale), 3); // Minimum 0.2, maksimum 3 ölçekte

    overlayImage.style.transform = `translate(-50%, -50%) scale(${scale})`;
});
